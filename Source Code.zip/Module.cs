﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace BouncyChallenge
{
    public class Module : ETGModule
    {
        public override void Start()
        {
            try
            {
                ETGModConsole.Log("Module started");
                NumberOfAdditionalBounces = 1;
                ETGModConsole.Commands.AddGroup("bouncing", delegate (string[] args)
                {
                    ETGModConsole.Log("Type 'bouncing toggle' to turn the challenge on and off, and 'bouncing number X' to adjust how many bounces each bullet has.");
                });
                ETGModConsole.Commands.GetGroup("bouncing").AddUnit("toggle", delegate (string[] args)
                {
                    if (BouncingEnabled)
                    {
                        ETGModConsole.Log("Bouncing has been disabled");
                        BouncingEnabled = false;
                    }
                    else
                    {
                        ETGModConsole.Log("Bouncing has been enabled");
                        BouncingEnabled = true ;
                    }
                });
                ETGModConsole.Commands.GetGroup("bouncing").AddUnit("numbounces", delegate (string[] args)
                {
                    if (args != null && args[0] != null)
                    {
                        if (args.Count() > 1)
                        {
                            ETGModConsole.Log("ERROR: TOO MANY ARGUMENTS");
                        }
                        else
                        {
                            try
                            {
                                int numbounce = int.Parse(args[0]);
                                if (numbounce > 0)
                                {
                                    NumberOfAdditionalBounces = numbounce;
                                    ETGModConsole.Log("Number of bounces set to "+ numbounce);

                                }
                                else
                                {
                                    ETGModConsole.Log("ERROR: INPUTTER NUMBER OF BOUNCES MUST BE GREATER THAN 0");

                                }
                            }
                            catch (Exception e)
                            {
                                ETGModConsole.Log(e.ToString());
                            }
                        }
                    }
                });
                DoBounceHook.Init();
                ETGModConsole.Log("Bouncy challenge initialised successfully.");
            }
            catch (Exception e)
            {
                ETGModConsole.Log(e.Message);
                ETGModConsole.Log(e.StackTrace);
            }
        }
        public static int NumberOfAdditionalBounces = 1;
        public static bool BouncingEnabled = false;
        public override void Exit() { }
        public override void Init() { }
    }
}
