﻿using MonoMod.RuntimeDetour;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using UnityEngine;

namespace BouncyChallenge
{
    public delegate TResult Func<in T1, in T2, in T3, in T4, out TResult>(T1 arg1, T2 arg2, T3 arg3, T4 arg4);
    class DoBounceHook
    {
        public static void Init()
        {
            try
            {
                ETGModConsole.Log("Init ran");

                ProjectileCreationHook = new Hook(
                    typeof(SpawnManager).GetMethod("SpawnProjectile", new Type[] { typeof(GameObject), typeof(Vector3), typeof(Quaternion), typeof(bool) }),
                    typeof(DoBounceHook).GetMethod("AddBounce")
                );
            }
            catch (Exception e)
            {
                ETGModConsole.Log(e.Message);
                ETGModConsole.Log(e.StackTrace);
            }
        }
        public static GameObject AddBounce(Func<GameObject, Vector3, Quaternion, bool, GameObject> orig, GameObject bullet, Vector3 pos, Quaternion rot, bool ignorePools = true)
        {
            try
            {
                GameObject SpawnedBulletObj = orig(bullet, pos, rot, ignorePools);
                if (Module.BouncingEnabled)
                {
                    if (SpawnedBulletObj && SpawnedBulletObj.GetComponent<Projectile>())
                    {

                        Projectile proj = SpawnedBulletObj.GetComponent<Projectile>();
                        proj.StartCoroutine(AddBounceCoroutine(proj));
                        
                    }
                }

                return SpawnedBulletObj;

            }
            catch (Exception e)
            {
                ETGModConsole.Log(e.Message);
                ETGModConsole.Log(e.StackTrace);
                return null;
            }
        }
        public static IEnumerator AddBounceCoroutine(Projectile proj)
        {
            yield return null;
            if (proj.Owner == null || proj.Owner is AIActor)
            {
                proj.baseData.range *= 3;
                if (proj.GetComponent<BounceProjModifier>() != null)
                {
                    proj.GetComponent<BounceProjModifier>().numberOfBounces += Module.NumberOfAdditionalBounces;
                    proj.GetComponent<BounceProjModifier>().percentVelocityToLoseOnBounce = 0;
                }
                else
                {
                    BounceProjModifier bouncy = proj.gameObject.GetOrAddComponent<BounceProjModifier>();
                    bouncy.numberOfBounces = Module.NumberOfAdditionalBounces;
                    bouncy.percentVelocityToLoseOnBounce = 0;
                }
            }
            yield break;
        }
        public static Hook ProjectileCreationHook;
    }
}
